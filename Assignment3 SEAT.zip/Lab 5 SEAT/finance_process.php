<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $car_price = $_POST["car_price"];
    $down_payment = $_POST["down_payment"];
    $loan_term = $_POST["loan_term"];
    $interest_rate = $_POST["interest_rate"] / 100;

    // Loan amount after down payment
    $loan_amount = $car_price - $down_payment;

    // Monthly interest rate
    $monthly_rate = $interest_rate / 12;

    // Number of months
    $num_payments = $loan_term * 12;

    // Monthly payment formula
    $monthly_payment = ($loan_amount * $monthly_rate) / (1 - pow(1 + $monthly_rate, -$num_payments));

    // Format the result in euros (€)
    $monthly_payment = number_format($monthly_payment, 2, '.', '.');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Finance Calculation</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="logo-container">
    <img src="images/Car.jpg" alt="Logo" class="logo">
    <span class="website-name">Cars Galore</span>
</div>

<main>
    <h1>Finance Calculation Result</h1>
    <?php if (isset($monthly_payment)) : ?>
        <p>Your estimated monthly payment is: <strong>€<?php echo $monthly_payment; ?></strong></p>
        <a href="finance.php">Go Back</a>
    <?php else : ?>
        <p>There was an error calculating your payment.</p>
    <?php endif; ?>
</main>

<?php include 'footer.php'; ?>

</body>
</html>
