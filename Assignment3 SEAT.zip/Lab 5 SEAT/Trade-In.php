<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Trade-In</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="logo-container">
    <img src="images/Car.jpg" alt="Logo" class="logo">
    <span class="website-name">Cars Galore</span>
</div>

<main>
    <h1>Trade-In Page</h1>
    <p>Looking for a trade-in? Just enter your car details, and we will estimate its value.</p>
</main>

<?php include 'footer.php'; ?>

</body>
</html>
