<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Finance</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="logo-container">
    <img src="images/Car.jpg" alt="Logo" class="logo">
    <span class="website-name">Cars Galore</span>
</div>

<main>
    <h1>Finance Options</h1>
    <p>Looking for financing options for your next car? We offer flexible plans to suit your budget.</p>

    <h2>Get a Quote</h2>
    <form action="finance_process.php" method="POST">
        <label for="car_price">Car Price (€):</label>
        <input type="number" id="car_price" name="car_price" required>

        <label for="down_payment">Down Payment (€):</label>
        <input type="number" id="down_payment" name="down_payment" required>

        <label for="loan_term">Loan Term (years):</label>
        <select id="loan_term" name="loan_term">
            <option value="3">3 Years</option>
            <option value="5">5 Years</option>
            <option value="7">7 Years</option>
        </select>

        <label for="interest_rate">Interest Rate (%):</label>
        <input type="number" id="interest_rate" name="interest_rate" step="0.01" required>

        <button type="submit">Calculate Monthly Payment</button>
    </form>
</main>

<?php include 'footer.php'; ?>

</body>
</html>
