<?php
echo '<header>
    <nav>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="search.php">Search</a></li>
            <li><a href="source.php">Source</a></li>
            <li><a href="enquire.php">Enquire</a></li>
            <li><a href="trade-in.php">Trade-In</a></li>
            <li><a href="finance.php">Finance</a></li>
        </ul>
    </nav>
</header>';
?>
