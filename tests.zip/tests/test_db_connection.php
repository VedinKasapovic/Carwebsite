<?php
include('../SEAT_Assessment_4/db.php');

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo "Test Failed: Database Connection Error";
} else {
    echo "Test Passed: Database Connected Successfully";
}
$conn->close();
?>
