<?php
function approveFinance($income, $loanAmount) {
    return ($income >= ($loanAmount / 2));
}
$test_cases = [
    ['income' => 30000, 'loanAmount' => 10000],
    ['income' => 4000, 'loanAmount' => 10000],
];
foreach ($test_cases as $case) {
    echo "Testing Income: {$case['income']}, Loan Amount: {$case['loanAmount']} - ";
    if (approveFinance($case['income'], $case['loanAmount'])) {
        echo "Approved\n";
    } else {
        echo "Rejected\n";
    }
}
?>