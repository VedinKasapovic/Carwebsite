<?php
$page = file_get_contents('../SEAT_Assessment_4/index.php');
if ($page) {
    echo "Test Passed: Index page loaded.";
} else {
    echo "Test Failed: Index page failed to load.";
}
?>
