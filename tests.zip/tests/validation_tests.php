<?php
// Validation Tests

$phone = "0831234567";
if (preg_match('/^[0-9]{10}$/', $phone)) { echo "Phone Valid\n"; } else { echo "Phone Invalid\n"; }

$email = "user@example.com";
if (filter_var($email, FILTER_VALIDATE_EMAIL)) { echo "Email Valid\n"; } else { echo "Email Invalid\n"; }

$name = "Klevis Malaj";
if (preg_match('/^[a-zA-Z\s]+$/', $name)) { echo "Name Valid\n"; } else { echo "Name Invalid\n"; }

$message = "I want to inquire.";
if (!empty(trim($message))) { echo "Message Valid\n"; } else { echo "Message Invalid\n"; }

$car_year = 2020;
$current_year = date('Y');
if ($car_year >= 2000 && $car_year <= $current_year) { echo "Car Year Valid\n"; } else { echo "Car Year Invalid\n"; }
?>