<?php
$host = "localhost";
$username = "root";
$password = ""; // Default for Laragon
$dbname = "car_dealership"; // Change this to your actual DB name

$dsn = "mysql:host=$host;dbname=$dbname";
$options = array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
);
