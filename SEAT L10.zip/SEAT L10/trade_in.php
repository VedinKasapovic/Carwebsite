<?php
include('header.php');
require_once 'C:\laragon\www\SEAT L10\trade_in.php';
require_once 'config.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $current_car = $_POST['current_car'] ?? '';
    $condition = $_POST['condition'] ?? '';
    $desired_value = $_POST['desired_value'] ?? '';
    try {
        $connection = new PDO($dsn, $username, $password, $options);

        $sql = "INSERT INTO trade_ins (name, email, current_car, condition, desired_value) VALUES (:name, :email, :current_car, :condition, :desired_value)";
        $stmt = $connection->prepare($sql);
        $stmt->bindParam(':name', $name, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':current_car', $current_car, PDO::PARAM_STR);
        $stmt->bindParam(':condition', $condition, PDO::PARAM_STR);
        $stmt->bindParam(':desired_value', $desired_value, PDO::PARAM_STR);
        $stmt->execute();

        echo "<p>Form submitted successfully!</p>";
    } catch (PDOException $error) {
        echo "<p>Error: " . $error->getMessage() . "</p>";
    }
}
?>
<main>
    <h1>Trade-In Request</h1>
    <form action="trade_in.php" method="POST">
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Your Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="car_model">Car Model:</label>
        <input type="text" id="car_model" name="car_model" required>

        <label for="year">Car Year:</label>
        <input type="number" id="year" name="year" required>

        <label for="condition">Car Condition:</label>
        <textarea id="condition" name="condition" required></textarea>

        <input type="submit" value="Submit Trade-In Request">
    </form>
</main>

<?php include('footer.php'); ?>
