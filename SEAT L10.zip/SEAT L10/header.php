<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Dealership</title>
    <link rel="stylesheet" href="styles.css">  <!-- Link to your styles.css -->
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="enquire.php">Enquire</a></li>
                <li><a href="trade_in.php">Trade-In</a></li>
                <li><a href="finance.php">Finance</a></li>
            </ul>
        </nav>
    </header>
