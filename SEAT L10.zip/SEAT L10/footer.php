<footer>
    <p>&copy; 2025 Car Dealership. All rights reserved.</p>
</footer>
</body>
</html>
