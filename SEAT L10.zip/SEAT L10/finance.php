<?php
include('header.php');
require_once 'config.php';
require_once 'C:\laragon\www\SEAT L10\finance.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $employment = $_POST['employment'] ?? '';
    $income = $_POST['income'] ?? '';
    $comments = $_POST['comments'] ?? '';
    try {
        $connection = new PDO($dsn, $username, $password, $options);

        $sql = "INSERT INTO finance (name, email, employment, income, comments) VALUES (:name, :email, :employment, :income, :comments)";
        $stmt = $connection->prepare($sql);
        $stmt->bindParam(':name', $name, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':employment', $employment, PDO::PARAM_STR);
        $stmt->bindParam(':income', $income, PDO::PARAM_STR);
        $stmt->bindParam(':comments', $comments, PDO::PARAM_STR);
        $stmt->execute();

        echo "<p>Form submitted successfully!</p>";
    } catch (PDOException $error) {
        echo "<p>Error: " . $error->getMessage() . "</p>";
    }
}
?>
<main>
    <h1>Car Financing Options</h1>
    <p>We offer competitive financing options to help you purchase your next car.</p>
    <p>Fill out the form below to apply for financing:</p>

    <form action="finance.php" method="POST">
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Your Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="car_model">Car Model:</label>
        <input type="text" id="car_model" name="car_model" required>

        <label for="loan_amount">Loan Amount:</label>
        <input type="number" id="loan_amount" name="loan_amount" required>

        <input type="submit" value="Apply for Financing">
    </form>

</main>

<?php include('footer.php'); ?>
