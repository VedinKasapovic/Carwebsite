<?php
include('header.php');
include('db_connection.php');

// Get the car ID from the URL
$id = $_GET['id'];

// Fetch car details from the database
$sql = "SELECT * FROM cars WHERE id = $id";
$result = $conn->query($sql);
$car = $result->fetch_assoc();

if (!$car) {
    echo "<p>Car not found!</p>";
} else {
    echo "<h1>" . $car['name'] . "</h1>";
    echo "<p><strong>Price:</strong> $" . $car['price'] . "</p>";
    echo "<p><strong>Description:</strong> " . $car['description'] . "</p>";
}
?>
<p><a href="enquire.php?car_id=<?php echo $car['id']; ?>">Make an Inquiry</a></p>
<p><a href="trade_in.php">Submit a Trade-In Request</a></p>
<p><a href="finance.php">Learn About Financing Options</a></p>

<?php include('footer.php'); ?>
