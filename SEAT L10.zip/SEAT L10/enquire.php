<?php
include('header.php');
require_once 'C:\laragon\www\SEAT L10\enquire.php';
require_once 'config.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $car_id = $_POST['car_id'] ?? '';
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';
    try {
        $connection = new PDO($dsn, $username, $password, $options);

        $sql = "INSERT INTO inquiries (car_id, name, email, message) VALUES (:car_id, :name, :email, :message)";
        $stmt = $connection->prepare($sql);
        $stmt->bindParam(':car_id', $car_id, PDO::PARAM_STR);
        $stmt->bindParam(':name', $name, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':message', $message, PDO::PARAM_STR);
        $stmt->execute();

        echo "<p>Form submitted successfully!</p>";
    } catch (PDOException $error) {
        echo "<p>Error: " . $error->getMessage() . "</p>";
    }
}
?>
<main>
    <h1>Inquiry Form</h1>
    <form action="enquire.php?car_id=<?php echo $car_id; ?>" method="POST">
        <label for="name">Your Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Your Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="message">Your Message:</label>
        <textarea id="message" name="message" required></textarea>

        <input type="submit" value="Submit Inquiry">
    </form>
</main>

<?php include('footer.php'); ?>
