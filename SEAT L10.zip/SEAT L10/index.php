<?php include('header.php'); ?>

<main>
    <h1>Welcome to Our Car Dealership</h1>
    <p>Browse our latest car models and make an inquiry for your preferred choice.</p>

    <h2>Our Car Listings</h2>
    <ul>
        <?php
        include('db_connection.php');
        $sql = "SELECT * FROM cars";
        $result = $conn->query($sql);

        while ($row = $result->fetch_assoc()) {
            echo "<li><a href='car_details.php?id=" . $row['id'] . "'>" . $row['name'] . " - $" . $row['price'] . "</a></li>";
        }
        ?>
    </ul>
</main>
<?php include('footer.php'); ?>
