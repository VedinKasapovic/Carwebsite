<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="logo-container">
    <img src="images/Car.jpg" alt="Logo" class="logo">
    <span class="website-name">Cars Galore</span>
</div>

<main>
    <h1>Welcome to Home Page</h1>
    <p>Welcome to Cars Galore. This is the home page. We can help you source, enquire and get an estimated value of a trade-in for your car.</p>
</main>

<?php include 'footer.php'; ?>

</body>
</html>
