<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<?php include 'header.php'; ?>

<div class="logo-container">
    <img src="images/Car.jpg" alt="Logo" class="logo">
    <span class="website-name">Cars Galore</span>
</div>

<main>
    <h1>Search</h1>
    <p>Search for all of our products and services that we have to offer.</p>
    <form action="search_results.php" method="GET">
        <input type="text" name="query" placeholder="Search...">
        <button type="submit">Search</button>
    </form>
</main>

<?php include 'footer.php'; ?>

</body>
</html>
