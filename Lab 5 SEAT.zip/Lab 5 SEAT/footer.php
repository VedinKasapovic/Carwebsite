<?php
echo '<footer>
    <p>&copy; ' . date("Y") . ' Cars Galore. All rights reserved.</p>
</footer>';
?>
