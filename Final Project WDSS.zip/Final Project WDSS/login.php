<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$_POST['username']]);
    $user = $stmt->fetch();
    if ($user && password_verify($_POST['password'], $user['password'])) {
        $_SESSION['user'] = $user['username'];
        header('Location: cart.php');
        exit;
    } else {
        echo "Invalid credentials.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>

<div style="padding: 10px;">
    <img src="images/car.jpg" width="200" height="200" alt="Car Logo" style="float: left;">
</div>

<div style="background-color: #333; overflow: hidden; margin-left: 320px;">
    <a href="index.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Home</a>
    <a href="enquire.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Enquire</a>
    <a href="trade_in.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Trade-In</a>
    <a href="finance.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Finance</a>
    <a href="feedback.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Feedback</a>
    <a href="search.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Search</a>
    <a href="register.php" style="float: right; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Register</a>
    <a href="login.php" style="float: right; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Login</a>
    <a href="cart.php" style="float: right; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Cart</a>
</div>

<div class="container" style="margin-left: 320px;">
    <h2>Login</h2>
    <form method="POST">
        Username: <input name="username" required><br>
        Password: <input name="password" type="password" required><br>
        <button type="submit">Login</button>
    </form>
</div>
</body>
</html>
