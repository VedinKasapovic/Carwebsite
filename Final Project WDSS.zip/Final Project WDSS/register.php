<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $check->execute([$username]);
    if ($check->rowCount() > 0) {
        echo "Username already taken. <a href='register.php'>Try again</a>";
    } else {
        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->execute([$username, $password]);
        echo "Registration successful. <a href='login.php'>Login</a>";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Register</title></head>
<body>

<div style="padding: 10px;">
    <img src="images/car.jpg" width="200" height="200" alt="Car Logo" style="float: left;">
</div>

<div style="background-color: #333; overflow: hidden; margin-left: 320px;">
    <a href="index.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Home</a>
    <a href="enquire.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Enquire</a>
    <a href="trade_in.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Trade-In</a>
    <a href="finance.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Finance</a>
    <a href="feedback.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Feedback</a>
    <a href="search.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Search</a>
    <a href="register.php" style="float: right; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Register</a>
    <a href="login.php" style="float: right; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Login</a>
    <a href="cart.php" style="float: right; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Cart</a>
</div>

<div class="container" style="margin-left: 320px;">
    <h2>Register</h2>
    <form method="POST">
        Username: <input name="username" required><br>
        Password: <input name="password" type="password" required><br>
        <button type="submit">Register</button>
    </form>
</div>
</body>
</html>
