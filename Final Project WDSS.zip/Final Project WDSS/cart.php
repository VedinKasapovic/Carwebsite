<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item = htmlspecialchars($_POST['item']);
    $_SESSION['cart'][] = $item;
}
?>
<!DOCTYPE html>
<html>
<head><title>Shopping Cart</title></head>
<body>

<div style="padding: 10px;">
    <img src="images/car.jpg" width="200" height="200" alt="Car Logo" style="float: left;">
</div>

<div style="background-color: #333; overflow: hidden; margin-left: 320px;">
    <a href="index.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Home</a>
    <a href="enquire.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Enquire</a>
    <a href="trade_in.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Trade-In</a>
    <a href="finance.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Finance</a>
    <a href="feedback.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Feedback</a>
    <a href="search.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Search</a>
    <a href="register.php" style="float: right; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Register</a>
    <a href="login.php" style="float: right; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Login</a>
    <a href="cart.php" style="float: right; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Cart</a>
</div>

<div class="container" style="margin-left: 320px;">
    <h2>Welcome, <?php echo $_SESSION['user']; ?></h2>
    <h3>Shopping Cart</h3>
    <ul>
    <?php foreach ($_SESSION['cart'] as $item) {
        echo "<li>$item</li>";
    } ?>
    </ul>
    <form method="POST">
        <input name="item" placeholder="Enter item to add" required>
        <button type="submit">Add to Cart</button>
    </form>
    <br>
    <a href="logout.php">Logout</a>
</div>
</body>
</html>
