<?php
include('db.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $income = (float)$_POST['income'];
    $loan_amount = (float)$_POST['loan_amount'];
    $sql = "INSERT INTO finance_applications (name, income, loan_amount) VALUES ('$name', $income, $loan_amount)";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Finance application submitted successfully!');</script>";
    } else {
        echo "<script>alert('Error submitting finance application.');</script>";
    }
}
?>
<body>
    <div style="padding: 10px;">
        <img src="images/car.jpg" width="200" height="200" alt="Car Logo" style="float: left;">
    </div>

    <div style="background-color: #333; overflow: hidden; margin-left: 320px;">
    </div>

    <div class="container" style="margin-left: 320px;">
    </div>
</body>
<div style="background-color: #333; overflow: hidden;">
  <div style="max-width: 1200px; margin: auto;">
    <a href="index.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Home</a>
    <a href="enquire.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Enquire</a>
    <a href="trade_in.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Trade-In</a>
    <a href="finance.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Finance</a>
    <a href="feedback.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Feedback</a>
    <a href="search.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Search</a>
  </div>
</div>


<style>
body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
.container { max-width: 1200px; margin: auto; padding: 20px; }
.card { border: 1px solid #ccc; border-radius: 5px; padding: 20px; margin: 10px; width: 200px; display: inline-block; vertical-align: top; text-align: center; }
input, textarea, select, button { width: 100%; padding: 10px; margin: 5px 0 15px 0; border: 1px solid #ccc; border-radius: 4px; }
button { background-color: #333; color: white; cursor: pointer; }
button:hover { background-color: #555; }
</style>

<div class="container">
<h1>Apply for Finance</h1>
<form method="POST">
    <input type="text" name="name" placeholder="Name" required>
    <input type="number" step="0.01" name="income" placeholder="Income" required>
    <input type="number" step="0.01" name="loan_amount" placeholder="Loan Amount" required>
    <button type="submit">Submit Application</button>
</form>
</div>
