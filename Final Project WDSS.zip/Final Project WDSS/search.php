<?php
require 'db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Cars</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        .container { max-width: 1200px; margin: auto; padding: 20px; }
        .card { border: 1px solid #ccc; border-radius: 5px; padding: 20px; margin: 10px; width: 200px; display: inline-block; vertical-align: top; text-align: center; }
        input, textarea, select, button { width: 100%; padding: 10px; margin: 5px 0 15px 0; border: 1px solid #ccc; border-radius: 4px; }
        button { background-color: #333; color: white; cursor: pointer; }
        button:hover { background-color: #555; }
    </style>
</head>
<body>
    <div style="padding: 10px;">
        <img src="images/car.jpg" width="200" height="200" alt="Car Logo" style="float: left;">
    </div>

    <div style="background-color: #333; overflow: hidden; margin-left: 320px;"></div>

    <div class="container" style="margin-left: 320px;"></div>

    <div style="background-color: #333; overflow: hidden;">
        <div style="max-width: 1200px; margin: auto;">
            <a href="index.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Home</a>
            <a href="enquire.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Enquire</a>
            <a href="trade_in.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Trade-In</a>
            <a href="finance.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Finance</a>
            <a href="feedback.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Feedback</a>
            <a href="search.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Search</a>
        </div>
    </div>

    <div class="container">
        <h1>Search Cars</h1>
        <form method="GET">
            <input type="text" name="query" placeholder="Model, Make Or Year" required>
            <button type="submit">Search</button>
        </form>
        <div style="margin-top:20px;">
            <?php
            if (isset($_GET['query'])) {
                $search = "%" . $_GET['query'] . "%";
                $stmt = $pdo->prepare("SELECT * FROM cars WHERE model LIKE ? OR make LIKE ? OR year LIKE ? OR price LIKE ?");
                $stmt->execute([$search, $search, $search, $search]);
                $results = $stmt->fetchAll();

                if ($results) {
                    foreach ($results as $row) {
                        echo "<div class='card'>";
                        echo "<b>" . htmlspecialchars($row['model']) . "</b><br>Year: " . htmlspecialchars($row['year']) . "<br>Price: €" . htmlspecialchars($row['price']);
                        echo "</div>";
                    }
                } else {
                    echo "<p>No cars found matching your search.</p>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
