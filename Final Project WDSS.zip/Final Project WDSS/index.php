<?php
require 'db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Car Sales</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        .container { max-width: 1200px; margin: auto; padding: 20px; }
        .card { border: 1px solid #ccc; border-radius: 5px; padding: 20px; margin: 10px; width: 200px; display: inline-block; vertical-align: top; text-align: center; }
        input, textarea, select, button { width: 100%; padding: 10px; margin: 5px 0 15px 0; border: 1px solid #ccc; border-radius: 4px; }
        button { background-color: #333; color: white; cursor: pointer; }
        button:hover { background-color: #555; }
    </style>
</head>
<body>
    <div style="padding: 10px;">
        <img src="images/car.jpg" width="200" height="200" alt="Car Logo" style="float: left;">
    </div>

    <div style="background-color: #333; overflow: hidden;">
        <div style="max-width: 1200px; margin: auto;">
            <a href="index.php" style="float: left; color: white; padding: 14px 16px; text-decoration: none;">Home</a>
            <a href="enquire.php" style="float: left; color: white; padding: 14px 16px; text-decoration: none;">Enquire</a>
            <a href="trade_in.php" style="float: left; color: white; padding: 14px 16px; text-decoration: none;">Trade-In</a>
            <a href="finance.php" style="float: left; color: white; padding: 14px 16px; text-decoration: none;">Finance</a>
            <a href="feedback.php" style="float: left; color: white; padding: 14px 16px; text-decoration: none;">Feedback</a>
            <a href="search.php" style="float: left; color: white; padding: 14px 16px; text-decoration: none;">Search</a>
            <a href="register.php" style="float: right; color: white; padding: 14px 16px; text-decoration: none;">Register</a>
            <a href="login.php" style="float: right; color: white; padding: 14px 16px; text-decoration: none;">Login</a>
            <a href="cart.php" style="float: right; color: white; padding: 14px 16px; text-decoration: none;">Cart</a>
        </div>
    </div>

    <div class="container">
        <h1>Available Cars</h1>
        <div style="margin-top:20px;">
        <?php
        $stmt = $pdo->query("SELECT * FROM cars");
        $cars = $stmt->fetchAll();
        foreach ($cars as $car) {
            echo "<div class='card'>";
            echo "<b>" . htmlspecialchars($car['model']) . "</b><br>Year: " . htmlspecialchars($car['year']) . "<br>Price: €" . htmlspecialchars($car['price']);
            echo "</div>";
        }
        ?>
        </div>
    </div>
</body>
</html>
