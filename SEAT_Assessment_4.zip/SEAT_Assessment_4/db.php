<?php
$servername = "localhost"; // Usually localhost
$username = "root";         // Your MySQL username (default for Laragon is "root")
$password = "";             // Your MySQL password (default for Laragon is empty)
$dbname = "cars_galore";    // Your database name (make sure it matches exactly)

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
