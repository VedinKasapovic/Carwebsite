<?php
include('db.php');
?>
<body>
    <div style="padding: 10px;">
        <img src="images/car.jpg" width="200" height="200" alt="Car Logo" style="float: left;">
    </div>

    <div style="background-color: #333; overflow: hidden; margin-left: 320px;">
    </div>

    <div class="container" style="margin-left: 320px;">
    </div>
</body>
<div style="background-color: #333; overflow: hidden;">
  <div style="max-width: 1200px; margin: auto;">
    <a href="index.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Home</a>
    <a href="enquire.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Enquire</a>
    <a href="trade_in.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Trade-In</a>
    <a href="finance.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Finance</a>
    <a href="feedback.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Feedback</a>
    <a href="search.php" style="float: left; color: white; text-align: center; padding: 14px 16px; text-decoration: none;">Search</a>
  </div>
</div>


<style>
body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
.container { max-width: 1200px; margin: auto; padding: 20px; }
.card { border: 1px solid #ccc; border-radius: 5px; padding: 20px; margin: 10px; width: 200px; display: inline-block; vertical-align: top; text-align: center; }
input, textarea, select, button { width: 100%; padding: 10px; margin: 5px 0 15px 0; border: 1px solid #ccc; border-radius: 4px; }
button { background-color: #333; color: white; cursor: pointer; }
button:hover { background-color: #555; }
</style>

<div class="container">
  <h1>Welcome to Our Car Dealership</h1>
  <p>Browse our latest car models and make an inquiry for your preferred choice.</p>
  <h2>Our Car Listings</h2>
  <form method="GET" action="search.php">
    <input type="text" name="query" placeholder="Search by Model or Make" required>
    <button type="submit">Search</button>
  </form>
  <div style="margin-top:20px;">
<?php
$result = mysqli_query($conn, "SELECT * FROM cars");
while ($row = mysqli_fetch_assoc($result)) {
    echo "<div class='card'>";
    echo "<b>" . htmlspecialchars($row['model']) . "</b><br>Year: " . $row['year'] . "<br>Price: €" . $row['price'];
    echo "</div>";
}
?>
  </div>
</div>
