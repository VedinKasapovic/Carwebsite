<?php
function isEligibleForTradeIn($carYear) {
    return $carYear >= 2015;
}
$testYear = 2018;
if (isEligibleForTradeIn($testYear)) {
    echo "Test Passed: Car is eligible for trade-in.";
} else {
    echo "Test Failed: Car not eligible for trade-in.";
}
?>