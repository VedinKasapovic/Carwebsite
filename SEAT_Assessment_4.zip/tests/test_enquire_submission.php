<?php
$_POST['name'] = 'Test User';
$_POST['email'] = 'test@example.com';
$_POST['phone'] = '1234567890';
$_POST['message'] = 'Test message';
if (!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['phone']) && !empty($_POST['message'])) {
    echo "Test Passed: Enquire form accepts input.";
} else {
    echo "Test Failed: Enquire form did not accept input.";
}
?>