<?php
function validateFinanceApplication($income, $loanAmount) {
    return $income >= ($loanAmount / 2);
}
$income = 30000;
$loanAmount = 10000;
if (validateFinanceApplication($income, $loanAmount)) {
    echo "Test Passed: Finance application validation successful.";
} else {
    echo "Test Failed: Finance application validation failed.";
}
?>