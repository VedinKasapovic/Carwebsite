<?php
function validateCarYear($year) {
    return ($year >= 2015 && $year <= 2025);
}
$test_cases = [2015, 2025, 2014, 2026];
foreach ($test_cases as $year) {
    echo "Testing Year: $year - ";
    if (validateCarYear($year)) {
        echo "Valid\n";
    } else {
        echo "Invalid\n";
    }
}
?>